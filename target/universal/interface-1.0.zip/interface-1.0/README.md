Interface
=========

####This repository contains implementation of an application that is the middleware of Management of Workflows using Functional Representation.

###Prerequisites
*  You have installed JVM in your Linux machine.

###References:  
*  http://www.oracle.com/technetwork/java/javase/downloads/index.html
